module.exports = {
  port: 3001,
  ghostMode: false,
  notify: false,
  server: true,
  startPath: "demo.html",
  files: [ 'build/*', 'demo.html' ]
};
